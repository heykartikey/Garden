package com.example.garden.view.main

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

class FirebaseLikesRepository constructor(
    private val ref: DatabaseReference,
) : LikesRepository {
    override suspend fun getLikes(userId: String): Flow<List<String>> =
        withContext(Dispatchers.IO) {
            return@withContext callbackFlow {
                val listener = object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        trySend(
                            (snapshot.value as? Map<String, Any>)?.keys?.toList() ?: listOf()
                        )
                    }

                    override fun onCancelled(error: DatabaseError) {}
                }

                ref.child(userId).addValueEventListener(listener)

                awaitClose {
                    ref.child(userId).removeEventListener(listener)
                }
            }
        }

    override suspend fun updateLike(userId: String, feedId: String, liked: Boolean) {
        withContext(Dispatchers.IO) {
            when (liked) {
                true -> ref.child(userId).child(feedId).setValue(true)
                false -> ref.child(userId).child(feedId).removeValue()
            }
        }
    }
}