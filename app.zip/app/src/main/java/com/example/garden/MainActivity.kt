package com.example.garden

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.SnackbarDuration
import androidx.compose.material.Surface
import androidx.compose.material.rememberScaffoldState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.garden.ui.theme.GardenTheme
import com.example.garden.view.add_video.AddVideoViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            GardenTheme {


                val scaffoldState = rememberScaffoldState() // this contains the `SnackbarHostState`
                val coroutineScope = rememberCoroutineScope()

                val addVideoViewModel: AddVideoViewModel = hiltViewModel()
                val uploadDone = addVideoViewModel.uploadStatus

                println(uploadDone)

                LaunchedEffect(uploadDone) {
                    if (uploadDone) {
                        coroutineScope.launch {
                            scaffoldState.snackbarHostState.showSnackbar(
                                "Upload Done",
                                null,
                                SnackbarDuration.Short
                            )
                        }
                    }
                }
//                LaunchedEffect(Unit) {
//                    println(addVideoViewModel.uploadDone)
//                    when (addVideoViewModel.uploadDone) {
//                        0 -> coroutineScope.launch {
//                            scaffoldState.snackbarHostState.showSnackbar(
//                                "Uploading...",
//                                duration = SnackbarDuration.Short
//                            )
//                        }
//                        1 -> {
//                            coroutineScope.launch {
//                                scaffoldState.snackbarHostState.showSnackbar(
//                                    "Done...",
//                                    duration = SnackbarDuration.Short
//                                )
//                            }
//
//                            addVideoViewModel.uploadDone = -1
//                        }
//                        else -> Unit
//                    }

//                }
                Surface(
                    modifier = Modifier
                        .background(MaterialTheme.colors.background)
                        .windowInsetsPadding(
                            WindowInsets.safeDrawing
                        )
                ) {
                    Scaffold(
                        scaffoldState = scaffoldState,
                    ) {
                        Box(modifier = Modifier.padding(it)) { // Silent the error

                            // TODO: Add a central Snackbar host

                            Navigation(addVideoViewModel, coroutineScope, scaffoldState)
                        }
                    }
                }
            }
        }
    }
}