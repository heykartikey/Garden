package com.example.garden

import android.app.Application
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GardenApp : Application()

@Preview
@Preview(uiMode = Configuration.UI_MODE_NIGHT_YES)
annotation class DayNightPreview