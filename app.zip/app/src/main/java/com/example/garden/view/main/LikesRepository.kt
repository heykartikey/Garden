package com.example.garden.view.main

import kotlinx.coroutines.flow.Flow

interface LikesRepository {
    suspend fun getLikes(userId: String): Flow<List<String>>
    suspend fun updateLike(userId: String, feedId: String, liked: Boolean)
}