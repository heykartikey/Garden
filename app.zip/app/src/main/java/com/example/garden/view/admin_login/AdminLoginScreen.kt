package com.example.garden.view.admin_login

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.garden.ui.theme.GardenTheme

@Composable
fun AdminLoginScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        OutlinedTextField(value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth())
        Button(elevation = null, onClick = {}, modifier = Modifier.fillMaxWidth(), shape = RectangleShape) {
            Text(text = "Login")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AdminLoginScreenPreview() {
    GardenTheme {
        AdminLoginScreen()
    }
}